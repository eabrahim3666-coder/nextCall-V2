import React from 'react';
import { ThreeHeroScene } from './components/ThreeHeroScene';

export default function App() {
  return (
    <div className="w-screen h-screen relative overflow-hidden bg-black">
      {/* Full-screen Pure 3D WebGL Canvas Layer */}
      <div className="absolute inset-0 z-0">
        <ThreeHeroScene
          theme="dark"
          mode="interactive"
        />
      </div>
    </div>
  );
}

