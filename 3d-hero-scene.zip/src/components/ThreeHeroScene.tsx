import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { ThemeMode, InteractionMode, PerfStats } from '../types';

interface ThreeHeroSceneProps {
  theme: ThemeMode;
  mode: InteractionMode;
  onUpdatePerf?: (stats: PerfStats) => void;
}

export const ThreeHeroScene: React.FC<ThreeHeroSceneProps> = ({
  theme,
  mode,
  onUpdatePerf,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const modeRef = useRef<InteractionMode>(mode);
  const themeRef = useRef<ThemeMode>(theme);

  // Sync refs to avoid re-binding scene on every prop change
  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);

  useEffect(() => {
    themeRef.current = theme;
  }, [theme]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // --- SCENE SETUP ---
    const scene = new THREE.Scene();
    
    // Set background color
    const bgColor = theme === 'dark' ? new THREE.Color(0x000000) : new THREE.Color(0xffffff);
    scene.background = bgColor;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // Camera setup - narrow FOV perspective for crisp isometric architectural feel
    const camera = new THREE.PerspectiveCamera(28, width / height, 0.1, 100);
    const baseCamPos = new THREE.Vector3(18, 22, 18);
    camera.position.copy(baseCamPos);
    camera.lookAt(0, -0.5, 0);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = false; // Disabled real-time shadows for 60fps requirement
    container.appendChild(renderer.domElement);

    // --- LIGHTS ---
    const ambientLight = new THREE.AmbientLight(
      theme === 'dark' ? 0x141226 : 0xf0f4f8,
      theme === 'dark' ? 1.6 : 2.5
    );
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(
      theme === 'dark' ? 0x6366f1 : 0x334155,
      theme === 'dark' ? 1.4 : 1.5
    );
    dirLight1.position.set(12, 22, 16);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(
      theme === 'dark' ? 0x38bdf8 : 0x0284c7,
      theme === 'dark' ? 0.9 : 0.8
    );
    dirLight2.position.set(-12, 12, -12);
    scene.add(dirLight2);

    // --- GRID SETUP ---
    const GRID_SIZE = 13; // 13x13 = 169 grid positions
    const SPACING = 1.15;
    const CUBE_SIZE = 0.95;
    const halfGrid = ((GRID_SIZE - 1) * SPACING) / 2;

    const mainGroup = new THREE.Group();
    scene.add(mainGroup);

    // 1. FLOOR DOT/CROSS MATRIX (Isometric ground plane with corner dark -> gray gradient)
    const floorDotGeometry = new THREE.BufferGeometry();
    const floorPositions: number[] = [];
    const floorColors: number[] = [];

    const cornerDotColor = theme === 'dark' ? new THREE.Color(0x020305) : new THREE.Color(0x94a3b8);
    const grayDotColor = theme === 'dark' ? new THREE.Color(0x475569) : new THREE.Color(0x475569);

    for (let i = 0; i < GRID_SIZE; i++) {
      for (let j = 0; j < GRID_SIZE; j++) {
        const x = i * SPACING - halfGrid;
        const z = j * SPACING - halfGrid;

        const tCorner = (Math.abs(x) + Math.abs(z)) / (2 * halfGrid);
        const dotColor = new THREE.Color().copy(cornerDotColor).lerp(grayDotColor, Math.pow(Math.max(0, 1 - tCorner), 1.2));

        floorPositions.push(x, 0, z);
        floorColors.push(dotColor.r, dotColor.g, dotColor.b);
      }
    }

    floorDotGeometry.setAttribute(
      'position',
      new THREE.Float32BufferAttribute(floorPositions, 3)
    );
    floorDotGeometry.setAttribute(
      'color',
      new THREE.Float32BufferAttribute(floorColors, 3)
    );

    // Custom circular dot texture for soft grid points
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(16, 16, 12, 0, Math.PI * 2);
      ctx.fill();
    }
    const dotTexture = new THREE.CanvasTexture(canvas);

    const floorPointsMaterial = new THREE.PointsMaterial({
      size: 0.12,
      vertexColors: true,
      map: dotTexture,
      transparent: true,
      alphaTest: 0.05,
      opacity: theme === 'dark' ? 0.75 : 0.6,
    });

    const floorPoints = new THREE.Points(floorDotGeometry, floorPointsMaterial);
    floorPoints.position.y = -0.02;
    mainGroup.add(floorPoints);

    // 2. CUBES INSTANCED MESH
    const boxGeometry = new THREE.BoxGeometry(CUBE_SIZE, CUBE_SIZE, CUBE_SIZE);
    
    // Cube Body Material - Pitch black faces so cubes blend stealthily into void black background
    const boxMaterial = new THREE.MeshBasicMaterial({
      color: theme === 'dark' ? 0x000000 : 0xf8fafc,
    });

    const instanceCount = GRID_SIZE * GRID_SIZE;
    const cubeMesh = new THREE.InstancedMesh(boxGeometry, boxMaterial, instanceCount);
    cubeMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mainGroup.add(cubeMesh);

    // 3. GLOWING EDGES INSTANCED MESH
    const edgesGeometry = new THREE.EdgesGeometry(boxGeometry);
    const edgeMaterial = new THREE.LineBasicMaterial({
      color: 0x8b5cf6,
      linewidth: 1.5,
      transparent: true,
      opacity: 0.8,
    });
    
    // We create individual wireframes for elevated edge highlights
    const edgeGroup = new THREE.Group();
    mainGroup.add(edgeGroup);

    const cubeEdgesList: THREE.LineSegments[] = [];
    for (let i = 0; i < instanceCount; i++) {
      const edgeSeg = new THREE.LineSegments(
        edgesGeometry,
        new THREE.LineBasicMaterial({
          color: 0x8b5cf6,
          transparent: true,
          opacity: 0,
        })
      );
      edgeSeg.visible = false;
      edgeGroup.add(edgeSeg);
      cubeEdgesList.push(edgeSeg);
    }

    // 4. FLOOR BASE PADS & VECTOR ARROWS
    const arrowGroup = new THREE.Group();
    mainGroup.add(arrowGroup);

    const createArrowPadGeometry = () => {
      const geometry = new THREE.BufferGeometry();
      const points: number[] = [];
      const s = CUBE_SIZE / 2 + 0.08;

      // Outer bounding pad square
      points.push(-s, 0, -s,  s, 0, -s);
      points.push( s, 0, -s,  s, 0,  s);
      points.push( s, 0,  s, -s, 0,  s);
      points.push(-s, 0,  s, -s, 0, -s);

      // 4 Directional Chevrons (Vector arrows pointing outwards)
      const d = s + 0.14;
      const arr = 0.09;

      // Top chevron
      points.push(0, 0, -d, -arr, 0, -d + arr);
      points.push(0, 0, -d,  arr, 0, -d + arr);

      // Bottom chevron
      points.push(0, 0, d, -arr, 0, d - arr);
      points.push(0, 0, d,  arr, 0, d - arr);

      // Right chevron
      points.push(d, 0, 0, d - arr, 0, -arr);
      points.push(d, 0, 0, d - arr, 0,  arr);

      // Left chevron
      points.push(-d, 0, 0, -d + arr, 0, -arr);
      points.push(-d, 0, 0, -d + arr, 0,  arr);

      geometry.setAttribute('position', new THREE.Float32BufferAttribute(points, 3));
      return geometry;
    };

    const arrowPadGeo = createArrowPadGeometry();
    const arrowPadsList: THREE.LineSegments[] = [];

    for (let i = 0; i < instanceCount; i++) {
      const arrowSeg = new THREE.LineSegments(
        arrowPadGeo,
        new THREE.LineBasicMaterial({
          color: 0x00f3ff,
          transparent: true,
          opacity: 0,
        })
      );
      arrowSeg.position.y = 0.01;
      arrowSeg.visible = false;
      arrowGroup.add(arrowSeg);
      arrowPadsList.push(arrowSeg);
    }

    // --- STATE TRACKING ARRAYS ---
    const heights = new Float32Array(instanceCount);
    const targetHeights = new Float32Array(instanceCount);

    // Color palette matching reference video: Electric Cyan -> Mint Teal -> Electric Blue -> Hot Pink/Magenta -> Purple
    const gradientPalette = [
      new THREE.Color('#00F3FF'), // Electric Cyan
      new THREE.Color('#00FFAA'), // Mint Teal
      new THREE.Color('#0066FF'), // Bright Electric Blue
      new THREE.Color('#FF0080'), // Hot Neon Pink / Magenta
      new THREE.Color('#9D00FF'), // Deep Purple
    ];

    // Invisible raycast ground plane
    const raycastPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const raycaster = new THREE.Raycaster();
    const mouseNorm = new THREE.Vector2(-999, -999);
    const targetMouseNorm = new THREE.Vector2(0, 0);
    const smoothMouseNorm = new THREE.Vector2(0, 0);
    
    let isMouseActive = false;
    let mouseInactivityTimer: number | null = null;

    // Mouse move listener
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);

      targetMouseNorm.set(x, y);
      mouseNorm.set(x, y);
      isMouseActive = true;

      if (mouseInactivityTimer) window.clearTimeout(mouseInactivityTimer);
      mouseInactivityTimer = window.setTimeout(() => {
        isMouseActive = false;
      }, 1200);
    };

    const handleMouseLeave = () => {
      isMouseActive = false;
      targetMouseNorm.set(0, 0);
    };

    window.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);

    // --- RESIZE HANDLER ---
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Temporary variables for animation loop (no garbage collection allocations)
    const dummyMatrix = new THREE.Matrix4();
    const dummyVector = new THREE.Vector3();
    const rayIntersect = new THREE.Vector3();
    const tempColor = new THREE.Color();
    const idleColor = new THREE.Color();
    const finalColor = new THREE.Color();
    const darkCornerColor = new THREE.Color(0x020305);
    const grayCenterColor = new THREE.Color(0x52525b);

    let animationFrameId: number;
    let clock = new THREE.Clock();
    let frameCount = 0;
    let lastTime = performance.now();

    // --- ANIMATION RENDER LOOP ---
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();
      const now = performance.now();
      frameCount++;

      // Update performance metrics every ~500ms
      if (now - lastTime >= 500) {
        if (onUpdatePerf) {
          onUpdatePerf({
            fps: Math.round((frameCount * 1000) / (now - lastTime)),
            drawCalls: renderer.info.render.calls,
            triangles: renderer.info.render.triangles,
          });
        }
        frameCount = 0;
        lastTime = now;
      }

      // 1. Theme Color Updates
      const currentTheme = themeRef.current;
      const currentMode = modeRef.current;

      const targetBg = currentTheme === 'dark' ? 0x000000 : 0xffffff;
      if (scene.background instanceof THREE.Color) {
        scene.background.setHex(targetBg);
      }

      const cubeBodyHex = currentTheme === 'dark' ? 0x000000 : 0xf8fafc;
      boxMaterial.color.setHex(cubeBodyHex);

      // 2. Camera Parallax Spring Interpolation
      // Smooth lerp mouse coordinates for camera spring motion
      smoothMouseNorm.x += (targetMouseNorm.x - smoothMouseNorm.x) * 0.05;
      smoothMouseNorm.y += (targetMouseNorm.y - smoothMouseNorm.y) * 0.05;

      // Parallax rotation & position offset (strictly 3-5% horiz, 2-3% vert)
      const maxCamOffsetX = 1.2;
      const maxCamOffsetY = 0.8;
      
      camera.position.x = baseCamPos.x + smoothMouseNorm.x * maxCamOffsetX;
      camera.position.y = baseCamPos.y + smoothMouseNorm.y * maxCamOffsetY;
      camera.position.z = baseCamPos.z - smoothMouseNorm.x * 0.6;
      camera.lookAt(0, -0.2, 0);

      // 3. Whole Scene Continuous Floating Motion (Breathing)
      // Very gentle sine floating: amplitude ~0.12 units, rotation <1 degree
      const sceneFloatY = Math.sin(elapsedTime * 0.8) * 0.08;
      const sceneRotZ = Math.sin(elapsedTime * 0.5) * 0.008;
      mainGroup.position.y = sceneFloatY;
      mainGroup.rotation.y = sceneRotZ;

      // 4. Raycasting to calculate target position on plane
      raycaster.setFromCamera(mouseNorm, camera);
      const isIntersecting = raycaster.ray.intersectPlane(raycastPlane, rayIntersect);

      // Calculate Target Elevation for each block based on mode & raycast
      for (let i = 0; i < GRID_SIZE; i++) {
        for (let j = 0; j < GRID_SIZE; j++) {
          const idx = i * GRID_SIZE + j;
          const x = i * SPACING - halfGrid;
          const z = j * SPACING - halfGrid;

          let targetH = 0;

          if (currentMode === 'interactive') {
            if (isMouseActive && isIntersecting) {
              const dx = x - rayIntersect.x;
              const dz = z - rayIntersect.z;
              const dist = Math.sqrt(dx * dx + dz * dz);

              const radius = 3.6;
              if (dist < radius) {
                const factor = Math.exp(-(dist * dist) / (2 * 1.2 * 1.2));
                targetH = factor * 1.4; // Max elevation height 1.4 units
              }
            } else {
              // Auto demo idle wave when user is idle
              const distFromCenter = Math.sqrt(x * x + z * z);
              const waveVal = Math.sin(elapsedTime * 1.8 - distFromCenter * 0.8);
              if (waveVal > 0.4) {
                targetH = (waveVal - 0.4) * 1.1;
              }
            }
          } else if (currentMode === 'breathing') {
            // Synchronized multi-cluster breathing
            const distCenter = Math.sqrt(x * x + z * z);
            const val = Math.sin(elapsedTime * 1.5 - distCenter * 0.6);
            if (val > 0.2) {
              targetH = Math.pow(val, 2) * 1.3;
            }
          } else if (currentMode === 'wave') {
            // Diagonal grid wave passing across scene
            const diagonal = (i + j) * 0.4;
            const val = Math.sin(elapsedTime * 2.2 - diagonal);
            if (val > 0.3) {
              targetH = (val - 0.3) * 1.2;
            }
          } else if (currentMode === 'sweep') {
            // Circular rotating radar sweep
            const angle = Math.atan2(z, x);
            const sweepAngle = (elapsedTime * 1.2) % (Math.PI * 2) - Math.PI;
            let diff = Math.abs(angle - sweepAngle);
            if (diff > Math.PI) diff = Math.PI * 2 - diff;

            if (diff < 0.6) {
              const dist = Math.sqrt(x * x + z * z);
              if (dist > 1.2 && dist < 6.5) {
                targetH = (1 - diff / 0.6) * 1.2;
              }
            }
          }

          targetHeights[idx] = targetH;

          // Smooth spring damping interpolation
          heights[idx] += (targetHeights[idx] - heights[idx]) * 0.12;
        }
      }

      // 5. Update Cube InstancedMesh and Edge Wireframes
      for (let i = 0; i < GRID_SIZE; i++) {
        for (let j = 0; j < GRID_SIZE; j++) {
          const idx = i * GRID_SIZE + j;
          const x = i * SPACING - halfGrid;
          const z = j * SPACING - halfGrid;

          const h = heights[idx];

          // Individual subtle sine floating per object
          const phaseOffset = i * 0.3 + j * 0.2;
          const objectFloat = Math.sin(elapsedTime * 1.2 + phaseOffset) * 0.04;

          const posY = CUBE_SIZE / 2 + h + objectFloat;

          // Set Instanced Box Matrix
          dummyVector.set(x, posY, z);
          dummyMatrix.setPosition(dummyVector);
          cubeMesh.setMatrixAt(idx, dummyMatrix);

          // Update Edges & Base Arrow Pads (Always visible to define glossy diamond grid shape)
          const edgeLine = cubeEdgesList[idx];
          const arrowPad = arrowPadsList[idx];

          edgeLine.visible = true;
          arrowPad.visible = true;
          edgeLine.position.copy(dummyVector);

          // 1. Base idle color gradient from corners (dark black) to center (gray)
          const tCorner = (Math.abs(x) + Math.abs(z)) / (2 * halfGrid);
          idleColor.copy(darkCornerColor).lerp(grayCenterColor, Math.pow(Math.max(0, 1 - tCorner), 1.1));

          // 2. Active neon continuous color field (Cyan -> Mint -> Blue -> Magenta -> Purple)
          const gridSpan = halfGrid * 2;
          const u = (x + halfGrid) / gridSpan;
          const v = (z + halfGrid) / gridSpan;
          let fieldVal = (u * 0.55 + v * 0.45 + elapsedTime * 0.02) % 1.0;
          if (fieldVal < 0) fieldVal += 1.0;

          const paletteLength = gradientPalette.length;
          const scaledPos = fieldVal * (paletteLength - 1);
          const index0 = Math.floor(scaledPos);
          const index1 = Math.min(index0 + 1, paletteLength - 1);
          const blendRatio = scaledPos - index0;

          tempColor.copy(gradientPalette[index0]).lerp(gradientPalette[index1], blendRatio);

          const intensity = Math.min(1.0, h / 0.75);

          // Blend from corner dark/gray base to active colourful neon as cubes elevate
          finalColor.copy(idleColor).lerp(tempColor, intensity);

          // Edge line material update
          const edgeMat = edgeLine.material as THREE.LineBasicMaterial;
          edgeMat.color.copy(finalColor);
          const idleEdgeOpacity = 0.12 + (1 - tCorner) * 0.22;
          edgeMat.opacity = idleEdgeOpacity + intensity * (0.85 - idleEdgeOpacity);

          // Base Arrow pad update
          arrowPad.position.set(x, 0.01 + sceneFloatY * 0.1, z);
          const arrowMat = arrowPad.material as THREE.LineBasicMaterial;
          arrowMat.color.copy(finalColor);
          const idlePadOpacity = 0.08 + (1 - tCorner) * 0.18;
          arrowMat.opacity = idlePadOpacity + intensity * (0.75 - idlePadOpacity);
        }
      }

      cubeMesh.instanceMatrix.needsUpdate = true;

      // Render
      renderer.render(scene, camera);
    };

    animate();

    // Clean up
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('resize', handleResize);

      if (mouseInactivityTimer) window.clearTimeout(mouseInactivityTimer);

      boxGeometry.dispose();
      boxMaterial.dispose();
      edgesGeometry.dispose();
      edgeMaterial.dispose();
      arrowPadGeo.dispose();
      floorDotGeometry.dispose();
      floorPointsMaterial.dispose();
      dotTexture.dispose();
      renderer.dispose();

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [theme]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full relative cursor-crosshair overflow-hidden select-none"
    />
  );
};
