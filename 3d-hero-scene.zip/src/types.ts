export type ThemeMode = 'dark' | 'light';

export type InteractionMode = 'interactive' | 'breathing' | 'wave' | 'sweep';

export interface SceneConfig {
  gridSize: number; // e.g. 13 or 15
  cubeSize: number; // size of each block in 3D units
  gap: number;      // spacing between blocks
  maxElevation: number; // maximum height block rises
  floatAmplitude: number; // sine float height
  floatSpeed: number;     // sine float frequency
}

export interface PerfStats {
  fps: number;
  drawCalls: number;
  triangles: number;
}
